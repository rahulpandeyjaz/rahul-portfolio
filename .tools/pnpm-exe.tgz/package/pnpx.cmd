@echo off
pnpm dlx %*
